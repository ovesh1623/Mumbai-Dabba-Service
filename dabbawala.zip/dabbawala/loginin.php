<?php
$UserId = $_POST['userid'];
$Password = $_POST['pwd'];
if(!empty($UserId) || !empty($Password))
{
  $db_host='localhost';
  $db_root='root';
  $db_password='';
  $db_databasename='dabbawala';
  $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
  if( mysqli_connect_error())
  {
    die('CONNECTION ERROR');
  }
  else {
    $result = "SELECT * FROM `login` WHERE `username` = '$UserId' and `password` = '$Password'";
    $rel = mysqli_query($conn,$result);
    if(mysqli_num_rows($rel)==1)
    {
      $conn->close();
      header("Location: http://localhost/dabbawala/admindetails.php");
    }
    else {
      echo "Invalid Username or Password";
    }
  }
}
 ?>
