<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Dabba Service</title>
    <link rel="stylesheet" href="digitaldabba.css" />
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">

  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <div class="head">
      <h1>Digital DabbaService</h1>
    </div>
    <div class="details">
      <div class="detailspad">

    </div>
    </div>
      <form class="formfilling" action="http://localhost/dabbawala/pin.php" method="post">
        <h1>Please fill the details</h1>
        <iframe src="https://www.google.com/maps/d/embed?mid=1rXkRUAmXtZr7Nym1NuHy1IkJWkSfSR33" width="600" height="500" style="float: right;"></iframe><br><br>
        <label for="name">Name</label><br>
        <input type="text" name="name1" value="" required><br><br>
        <label for="email">Email Address</label><br>
        <input type="text" name="email1" value="" required ><br><br>
        <label for="Contact numer">Contact Number</label><br>
        <input type="text" name="contact1" value=""required><br><br>
        <label for="Address">Address</label><br>
        <input type="text" name="address1" value=""required><br><br>
        <label for="Pincode">Enter the pincode</label><br>
        <input type="text" name="pincode" value="" required><br><br>
        <input type="submit" name="Submit" value="Submit"><br><br>
      </form>
  </body>
</html>
