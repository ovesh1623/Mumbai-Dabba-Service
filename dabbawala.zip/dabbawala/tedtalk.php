<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Ted Talks</title>
    <link rel="stylesheet" href="tedtalk1.css" />
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <div class="head">
      <h1>Ted Talks</h1>
    </div>
    <div class="details">
      <div class="detailspad">
      <p>We are humble people. We don’t know any theories nor have we learnt any strategy, still we share our experiences and learnings which we have gained from this legacy of 125 years for which we are honoured as “Management Gurus”. Here is a program that we can share with you:</p>
      <p>There are inscribed management lessons in each and every step within our delivery system. We work on four basic pillars i.e. Efficiency, Time management, Coordination, and cultureâ€”are perfectly aligned and mutually reinforcing. In the corporate world, it’s uncommon for managers to strive for that kind of synergy. While most, if not all, pay attention to some of the pillars, only a minority address all four. Let’s explore Mumbai Dabbawala’s methodology in depth.</p>
    </div>
    </div>
      <form class="formfilling" action="http://localhost/dabbawala/sendmail.php" method="post">
        <h1>Please fill the details</h1>
        <label for="name">Organization Name</label><br>
        <input type="text" id="name" name="name" value="" required><br><br>
        <label for="email">Email Address</label><br>
        <input type="text" id="email" name="email" value="" required><br><br>
        <label for="Contact numer">Contact Number</label><br>
        <input type="text" id="phone" name="contact" value=""required><br><br>
        <label for="your message">Your Message</label><br>
        <input type="text" name="yourmessage" value=""><br><br>
        <input type="submit" name="Submit" value="Submit"><br><br>
      </form>
  </body>
</html>
