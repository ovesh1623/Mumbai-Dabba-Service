<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Dabba Service</title>
    <link rel="stylesheet" href="dabbaservice.css" />
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <script type="text/javascript">
    function validateName()
    {
      name = document.getElementById("name").value;
      reg = /^[A-Za-z]+\s[A-Za-z]+$/;

      if(!reg.test(name))
      {
        document.getElementById("nameError").innerHTML="Please enter a valid name";
        return false;
      }
      else
      {
        document.getElementById("nameError").innerHTML="";
        return true;
      }
    }

    function validateEmail()
			{
				email = document.getElementById("email").value;
				reg = /^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;

				if(email=="")
				{
					document.getElementById("emailError").innerHTML="Please enter an email id";
					return false;
				}

				else if(!reg.test(email))
				{
					document.getElementById("emailError").innerHTML="Please enter a valid email id";
					return false;
				}
				else
				{
					document.getElementById("emailError").innerHTML="";
					return true;
				}
			}

			function validatePhone()
			{
				phone = document.getElementById("phone").value;
				reg = /^[0-9]{10}$/;

				if(!reg.test(phone))
				{
					document.getElementById("phoneError").innerHTML="Please enter a valid phone number";
					return false;
				}
				else
				{
					document.getElementById("phoneError").innerHTML="";
					return true;
				}
			}
    </script>
  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <div class="head">
      <h1>Dabba Service</h1>
    </div>
    <div class="details">
      <div class="detailspad">
      <p>Since 1890,Mumbai Army of 5,000 Dabbawalas fulfilling the hunger of almost 200,000 Mumbaikar with home-cooked food that we lug between home and office daily</p>
      <p>Our core service is Dabba delivery i.e. delivering home cooked food from your house/mess to your work place. We operate pan Mumbai from Virar to Churchgate and from Ambernath to Dadar. It’s not as simple as it sounds, Battle with time and weather our day ends with an emotional satisfaction and happiness because we firmly believe in the philosophy of “Anna daan is maha daan”(Donating food is the best charity)</p>
      <p>No worries if you are not from Mumbai, No worries if there is no one at your house to cook food for you. We have the solution for all food related issues because we love foodies, moreover we love vegetarians!</p>
      <p>We provide healthy home cooked food straight away from our kitchen to your table which would be appealing to your eye & to your palette too. Be it Dal or be it a gravy, our food is prepared under hygienic conditions using refined oil which best takes care of your heart, because for us your little heart is utmost important.</p>
      <p>So the struggle for healthy food gets over, Contact us for wide variety of options!</p>
    </div>
    </div>
      <form class="formfilling" action="http://localhost/dabbawala/dabbaservicedatabase.php" method="post">
        <h1>Please fill the details</h1>
        <label for="name">Name</label><br>
        <input type="text" id="name" name="name" value="" required onchange="return validateName()">
        <label id="nameError" class="error"></label><br><br>
        <label for="email">Email Address</label><br>
        <input type="text" id="email" name="email" value="" required onchange="return validateEmail()">
        <label id="emailError" class="error"></label><br><br>
        <label for="Contact numer">Contact Number</label><br>
        <input type="text" id="phone" name="contact" value=""required onchange="return validatePhone()">
        <label id="phoneError" class="error"></label><br><br>
        <label for="Pickup">Pickup Point</label><br>
        <input type="text" name="pickup" value=""required><br><br>
        <label for="localstation">Select the nearest local station to Pickup pont</label><br>
        <select name="localstat">
          <option value="Borivali">Borivali</option>
          <option value="Kandivali">Kandivali</option>
          <option value="Malad">Malad</option>
          <option value="Georegaon">Georegaon</option>
          <option value="Ram Mandir">Ram Mandir</option>
          <option value="Jogeshwari">Jogeshwari</option>
          <option value="Andheri">Andheri</option>
        </select><br><br>
        <label for="Drop">Drop Point</label><br>
        <input type="text" name="drop" value=""required><br><br>
        <label for="localstationd">Select the nearest local station to Drop point</label><br>
        <select name="localstatd">
          <option value="Borivali">Borivali</option>
          <option value="Kandivali">Kandivali</option>
          <option value="Malad">Malad</option>
          <option value="Georegaon">Georegaon</option>
          <option value="Ram Mandir">Ram Mandir</option>
          <option value="Jogeshwari">Jogeshwari</option>
          <option value="Andheri">Andheri</option>
        </select><br><br>
        <input type="submit" name="Submit" value="Submit"><br><br>
      </form>
  </body>
</html>
