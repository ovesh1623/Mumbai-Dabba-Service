<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="pin.css">
    <title>Details</title>
    <?php
    $Name = $_POST['name1'];
    $Email = $_POST['email1'];
    $Contact = $_POST['contact1'];
    $Address = $_POST['address1'];
    $pincode = $_POST['pincode'];
    $python = `python final.py $pincode`;


    if(!empty($Name) || !empty($Message)|| !empty($Contact)|| !empty($Address)|| !empty($pincode)){
      $db_host='localhost';
      $db_root='root';
      $db_password='';
      $db_databasename='dabbawala';
      $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
      if( mysqli_connect_error())
      {
        die('CONNECTION ERROR');
      }
      else {
        $result = "INSERT INTO `digitaldabba` (`name`, `email id`, `contact no`, `address`, `pincode`) VALUES ('$Name', '$Email', '$Contact', '$Address', '$pincode');";
        if(mysqli_query($conn,$result))
        {
          $conn->close();
        }
        else {
          echo "Unsuccessful ";
        }
      }
    }
     ?>
  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <section class="section section-light">
      <h1>Delivery Details</h1>
    </section>
    <div class="details">
      <div class="detailspad">
        <br>
        <?php  echo "<p> <b>Name- </b>" . $Name . "</p>"  ?><br><br>
        <?php  echo "<p><b>Email Id- </b>" . $Email . "</p>" ?><br><br>
        <?php  echo "<p><b>Contact Number- </b>" . $Contact . "</p>" ?><br><br>
        <?php  echo "<p><b>Address- </b>" . $Address . "</p>" ?><br><br>
        <?php  echo "<p><b>Time required for delivery- </b>" . $python . " minutes</p>" ?><br><br />
      </div>

    </div>
  </body>
</html>
