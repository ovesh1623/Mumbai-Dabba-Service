<?php

  if (isset($_GET['Submit'])) {
    # code...

    $pincode = $_GET['pincode'];
$python = `python final.py $pincode`;
echo "<script>alert('Time required $python');</script>";
}

?>
