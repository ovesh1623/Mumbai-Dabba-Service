<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="pin.css">
    <title>Dabbaservice Detail</title>
    <?php
    $Name = $_POST['name'];
    $EmailId = $_POST['email'];
    $Contact = $_POST['contact'];
    $Pickup = $_POST['pickup'];
    $Pickuppt = $_POST['localstat'];
    $Drop = $_POST['drop'];
    $Droppt = $_POST['localstatd'];
    if(!empty($Name) || !empty($EmailId)|| !empty($Contact)|| !empty($Pickup)|| !empty($Pickup)|| !empty($Drop)|| !empty($Droppt))
    {
      $db_host='localhost';
      $db_root='root';
      $db_password='';
      $db_databasename='dabbawala';
      $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
      if( mysqli_connect_error())
      {
        die('CONNECTION ERROR');
      }
      else {
        $sql1 = "SELECT `value` FROM `railway` WHERE `station`='$Pickuppt'";
        $res1 = mysqli_query($conn,$sql1);
        $val1 = mysqli_fetch_assoc($res1);

        $sql2 = "SELECT `value` FROM `railway` WHERE `station`='$Droppt'";
        $res2 = mysqli_query($conn,$sql2);
        $val2 = mysqli_fetch_assoc($res2);
        $fval = 250*($val1['value']-$val2['value']);
        if ($fval<0){
          $fval = $fval*-1;
        }
        elseif ($fval==0) {
          $fval = 250;
        }
        mysqli_free_result($res1);
        mysqli_free_result($res2);

        $result = "INSERT INTO `dabbaservice` (`name`, `email id`, `contact no`, `pickup add`, `pickup pointer`, `drop add`, `drop pointer`) VALUES ('$Name', '$EmailId', '$Contact', '$Pickup', '$Pickuppt', '$Drop', '$Droppt')";
        if(mysqli_query($conn,$result))
        {
          $conn->close();
        }
        else{
          echo "Unsuccessful insert ";
        }
      }
    }
     ?>
  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <section class="section section-light">
      <h1>Dabba-Service Invoice</h1>
    </section>
    <div class="details">
      <div class="detailspad">
        <br>
        <?php  echo "<p> <b>Name- </b>" . $Name . "</p>"  ?><br>
        <?php  echo "<p><b>Email Id- </b>" . $EmailId . "</p>" ?><br>
        <?php  echo "<p><b>Contact Number- </b>" . $Contact . "</p>" ?><br>
        <?php  echo "<p><b>Pickup point- </b>" . $Pickup . "</p>" ?><br>
        <?php  echo "<p><b>Drop point- </b>" . $Drop . " </p>" ?><br>
        <?php  echo "<p><b>Amount- Rs</b>" . $fval . "(per month)</p>" ?><br />
      </div>

    </div>
  </body>
</html>
