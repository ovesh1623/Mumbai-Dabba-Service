<?php
$Organizationname = $_POST['name'];
$EmailId = $_POST['email'];
$Contact = $_POST['contact'];
$Message = $_POST['yourmessage'];
if(!empty($Organizationname) || !empty($Message)|| !empty($Contact)|| !empty($EmailId))
{
  $db_host='localhost';
  $db_root='root';
  $db_password='';
  $db_databasename='dabbawala';
  $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
  if( mysqli_connect_error())
  {
    die('CONNECTION ERROR');
  }
  else {
    $result = "INSERT INTO `ted talks` (`organization name`, `email id`, `contact no`, `message`) VALUES ('$Organizationname', '$EmailId', '$Contact', '$Message');";
    if(mysqli_query($conn,$result))
    {
      $conn->close();
      header("Location: home.html");
    }
    else {
      echo "Unsuccessful ";
    }
  }
}
 ?>
