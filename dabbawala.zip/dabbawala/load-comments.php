<?php
$db_host='localhost';
$db_root='root';
$db_password='';
$db_databasename='dabbawala';
$commentNewCount = $_POST['commentNewCount']
echo "hello";
$conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
if( mysqli_connect_error())
{
  die('CONNECTION ERROR');
}
else {
  $result = "SELECT * FROM `contact` Limit $commentNewCount";
  $sql= mysqli_query($conn,$result);
  echo "hello";
  if(mysqli_num_rows($sql)>0){
    while($row = mysqli_fetch_assoc($sql)){
      echo "<p> Name-". $row['Name'] ."</p>";
      echo "<p> Email id-". $row['email id'] ."</p>";
      echo "<p> Message-". $row['Message'] ."</p>";
      echo "<br /><br />";
    }
  }
}
?>
