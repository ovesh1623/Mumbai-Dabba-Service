<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="login.css">
    <title>Login Page</title>
  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <section class="section section-light">
      <h1>Login</h1>
    </section>
    <form class="formfilling" action="http://localhost/dabbawala/loginin.php" method="post">
      <label for="userid">Userid </label><br><br>
      <input type="text" name="userid" value="" required><br><br>
      <label for="password">Password</label><br><br>
      <input type="password" name="pwd" value="" required><br><br><br>
      <input type="submit" name="submit" value="Verify">
    </form>
  </body>
</html>
