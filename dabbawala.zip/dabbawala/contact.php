<?php
$Name = $_POST['name'];
$EmailId = $_POST['email'];
$Message = $_POST['message'];
if(!empty($Name) || !empty($Message))
{
  $db_host='localhost';
  $db_root='root';
  $db_password='';
  $db_databasename='dabbawala';
  $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
  if( mysqli_connect_error())
  {
    die('CONNECTION ERROR');
  }
  else {
    $result = "INSERT INTO `contact` (`Name`,`email id`, `Message`) VALUES ('$Name','$EmailId', '$Message');";
    if(mysqli_query($conn,$result))
    {
      $conn->close();
      header("Location: home.html");
    }
    else {
      echo "Unsuccessful ";
    }
  }
}
 ?>
