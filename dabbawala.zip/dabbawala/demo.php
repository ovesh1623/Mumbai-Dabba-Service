<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Demo</title>
    <?php
    $demo = "Hello";
     ?>
  </head>
  <body>
    <?php
    echo "<p>" . $demo ."</p>";
    ?>
  </body>
</html>
