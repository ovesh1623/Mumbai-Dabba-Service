# -*- coding: utf-8 -*-
"""
Created on Fri Oct  4 19:39:20 2019

@author: MOHNISH
"""

#!C:/Users/MOHNISH/AppData/Local/Programs/Python/Python36/python.exe
import numpy as np

import sys
pincode = float(sys.argv[1])

import pickle

with open('model','rb') as file:
    model = pickle.load(file)
    result = model.predict(np.array([[pincode]]))
    value = result[0]
    print(value)