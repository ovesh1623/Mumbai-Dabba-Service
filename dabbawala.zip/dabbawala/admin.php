<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin page</title>
    <script type="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
          var commentCount = 1;
          $("button").click(function(){
            commentCount = commentCount +1;
            $("#comments").load("http://localhost/dabbawala/load-comments.php",{
              commentNewCount: commentCount
            });
          })
        })
    </script>
  </head>
  <body>
    <div id="comments">
      <?php
      $db_host='localhost';
      $db_root='root';
      $db_password='';
      $db_databasename='dabbawala';
      $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
      if( mysqli_connect_error())
      {
        die('CONNECTION ERROR');
      }
      else {
        $result = "SELECT * FROM `contact` Limit 1";
        $sql= mysqli_query($conn,$result);
        if(mysqli_num_rows($sql)>0){
          while($row = mysqli_fetch_assoc($sql)){
            echo "<p> Name-". $row['Name'] ."</p>";
            echo "<p> Email id- ". $row['email id'] ."</p>";
            echo "<p> Message- ". $row['Message'] ."</p>";
            echo "<br /><br />";
          }
        }
      }
      ?>
    </div>
    <button>Read more</button>
  </body>
</html>
