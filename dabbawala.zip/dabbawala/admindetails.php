<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Admin Details</title>
    <link rel="stylesheet" href="admindetails.css">
    <link href="https://fonts.googleapis.com/css?family=Kaushan+Script|Open+Sans+Condensed:300&display=swap" rel="stylesheet">
  </head>
  <body>
    <div class="home">
      <a href="home.html"><img src="home1.png"></a>
    </div>
    <section class="section section-light">
      <h1>User Details </h1>
    </section>
    <div class="tabContainer">
      <div class="buttonContainer">
        <button onclick="showPanel(0,'#997300')">Comments</button>
        <button onclick="showPanel(1,'#446600')">Ted Talks</button>
      </div>
      <div class="tabPanel">
        <?php
        $db_host='localhost';
        $db_root='root';
        $db_password='';
        $db_databasename='dabbawala';
        $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
        if( mysqli_connect_error())
        {
          die('CONNECTION ERROR');
        }
        else {
          $result = "SELECT * FROM `contact`";
          $sql= mysqli_query($conn,$result);
          if(mysqli_num_rows($sql)>0){
            while($row = mysqli_fetch_assoc($sql)){
              echo "<br /><p> Name-". $row['Name'] ."</p>";
              echo "<p> Email id- ". $row['email id'] ."</p>";
              echo "<p> Message- ". $row['Message'] ."</p>";
              echo "<br /><hr />";
            }
          }
        }
        ?>
      </div>
      <div class="tabPanel">
        <table>
          <tr>
            <th>Organisation Name</th>
            <th>Email Id</th>
            <th>Contact No</th>
            <th>Message</th>
          </tr>
          <?php
          $db_host='localhost';
          $db_root='root';
          $db_password='';
          $db_databasename='dabbawala';
          $conn= new mysqli($db_host,$db_root,$db_password,$db_databasename);
          if( mysqli_connect_error())
          {
            die('CONNECTION ERROR');
          }
          else{
            $result = "SELECT * FROM `ted talks`";
            $sql= mysqli_query($conn,$result);
            if(mysqli_num_rows($sql)>0){
              while($row = mysqli_fetch_assoc($sql)){
                echo "<tr><td>". $row['organization name'] ."</td><td>". $row['email id'] ."</td><td>". $row['contact no'] ."</td><td>". $row['message'] ."</td>";
              }
            echo "</table>";
            }
            else{
              echo "No Result";
            }
            $conn-> close();
          }
           ?>
        </table>
      </div>
    </div>
    <script src="admindetails.js"></script>
  </body>
</html>
